import pugPlugin from "vite-plugin-pug"

// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
    devtools: { enabled: true },
    app: {
        head: {
            charset: "utf-8",
            viewport: "width=device-width, initial-scale=1",
            link: [{ rel: "icon", type: "image/png", href: "/fav.png" }],
        },
    },
    css: [
        "~/assets/fonts/fonts.css",
        "~/assets/sass/global.sass",
    ],
    modules: [
        "@nuxtjs/prismic",
        "@nuxtjs/tailwindcss",
        // "@pinia/nuxt",
        // "@pinia-plugin-persistedstate/nuxt",
        // "@nuxtjs/robots",
        "@nuxtjs/device", // $device.isDesktop
        "nuxt-icon", // https://icones.js.org
        // "nuxt-simple-sitemap",
        'dayjs-nuxt', // https://nuxt.com/modules/dayjs
        '@hypernym/nuxt-anime',
        // '@nuxtjs/sitemap',
        // '@nuxtjs/seo',
        'nuxt-swiper',
    ],
    prismic: { endpoint: 'centre-of-nowhere' },

    vite: {
        plugins: [pugPlugin()],
    },
})
