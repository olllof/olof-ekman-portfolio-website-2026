<script setup>
useHead({
    title: "Centre of Nowhere",
    meta: [{ name: "description", content: "" }],
})

const router = useRouter()

const routeName = computed(() => router.currentRoute.value.name)


</script>

<template lang="pug">
#default.layout
    
    logo(
        v-show='routeName === "index"'
        :top='routeName === "index" ? "-16vw" : "0vw"' 
        :left='routeName === "index" ? "-30vw" : "0vw"' 
        :size='routeName === "index" ? "300vw" : "14vw"'
    )
    logo(
        top='280vw'
        left='-60vw'
        size='300vw'
        v-show='routeName === "index"'
    )
    
    app-header.pt-8.pb-4.fixed.text-center.w-full.z-20
    
    .wallpaper.relative.z-10.px-16.py-24
        
        .ontop(style='min-height: calc(100svh - 3rem)').relative.z-10.px-8.py-4.pt-12.pb-48
            
            
            #main.pt-4
                .content.flex.flex-col.w-100.justify-center.align-center(style='min-height: calc(100svh - 8rem)')
                    slot
        app-footer.pt-4
</template>

<style lang="sass">
.wallpaper
    background: pink
    mix-blend-mode: difference
    padding-bottom: 100vh
.ontop
    // border-radius: 12vw
    border-radius: 33vw
    // background: #31a
    background: #C9ED38
    color: #00C0FF
    // color: #31a

// #default
    // width: 100vw
    // overflow-x: hidden
//     height: calc(100vh - 3rem)
//     overflow: scroll
</style>