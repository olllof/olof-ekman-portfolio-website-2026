<script setup lang="ts">
const { client } = usePrismic()

// const { data: homepage } = await useAsyncData('homepage', () => 
//     client.getSingle('homepage')
// )

const { data: posts } = await useAsyncData('posts', () => client.getByType('post', { 
    pageSize: 100,
    // orderings: [
    //   { field: "my.year", direction: "desc" }
    // ],
}))


</script>

<template lang="pug">
#page.index
    .posts.flex.flex-wrap
        .post(v-for='(post, i) in posts.results' :key='post.id').mb-16.w-full
            nuxt-link(:to='`/posts/${post.uid}`')
                .px-8
                    prismic-rich-text(:field='post.data.title').mb-8.text-center
                    .flex
                        .w-1x12.order-1
                        
                        .w-2x12(:class='{ "order-2": i % 2 === 0, "order-3": i % 2 !== 0 }')
                            .image(:style='{ transform: "translateX("+ (Math.random() * 50 - 25) +"%) translateY("+ (Math.random() * 300 - 150) +"px)" }')
                                prismic-image(
                                    :field='post.data.featured_image'
                                ).invert.aspect-square.rounded-full.grayscale
                        
                        .w-7x12(:class='{ "order-2": i % 2 !== 0, "order-3": i % 2 === 0 }')
                            prismic-rich-text(:field='post.data.body')
</template>

<style lang="sass">
#page .image
    transition: transform 0.666s ease-in-out
</style>