<script setup>
const uid = useRoute().params.uid
const { client } = usePrismic()
const { data: post } = await useAsyncData('post', () => 
    client.getByUID('post', uid)
)

const aspect = (image) => {
    const ratio = image.gallery_item.dimensions.width / image.gallery_item.dimensions.height
    return `aspect-${Math.floor(ratio * 100)}x${Math.floor(ratio * 100)}`
}
</script>

<template lang="pug">
#page
    div(style='font-size: 10vw; line-height: 0.8;').text-center.mb-8.druk
        | {{  post.data.title[0].text }}
    
    //- img(:src="post.data.featured_image.Hero.url.split('?')[0] + '?auto=format%2Ccompress&fit=facearea&facepad=10&w=2400&h=1000'").invert.my-16.rounded-full.drop-shadow-2xl
    
    .gallery(v-if='post.data.gallery').my-16.drop-shadow-2xl
        //- pre {{ post.data.gallery }}
        Vue3Marquee(
            :duration='post.data.gallery.length * 10'
        ).rounded-2xl
            .image(v-for='(image, i) in post.data.gallery.filter(e => e.gallery_item.url)' :key='i')
                img(
                    :src='image.gallery_item.url.split("?")[0] + "?auto=format%2Ccompress&fit=max&h=1024"'
                    :style='{ height: "512px", width: (512 * image.gallery_item.dimensions.width / image.gallery_item.dimensions.height) + "px" }'
                ).invert.bg-purple-400
                    //- .rounded-2xl.mx-4
                    //- .rounded-lg.drop-shadow-2xl
                //- div().rounded-lg.drop-shadow-2xl
                    //- img(:src="image.gallery_item.url.split('?')[0] + '?auto=format%2Ccompress&fit=facearea&facepad=10&w=2400&h=1000'").rounded-lg.drop-shadow-2xl
                //- img(:src="image.image.url.split('?')[0] + '?auto=format%2Ccompress&fit=facearea&facepad=10&w=2400&h=1000'").rounded-lg.drop-shadow-2xl
    
    .flex
        .w-3x12
        .w-7x12.text-lg
            prismic-rich-text(:field='post.data.body')
    
    
    .embed.flex(v-if='post.data.embed').mt-12
        .w-2x12
        .w-8x12
            prismic-embed(:field='post.data.embed').invert.rounded-2xl
    
    
</template>
