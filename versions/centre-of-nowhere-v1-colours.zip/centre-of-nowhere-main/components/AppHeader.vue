<template lang="pug">
header#app-header
    nuxt-link(to='/')
        #name.flex.justify-center.align-center.gap-4.leading-none
            .kooltura.text-xl Centre of Nowhere
            .radio.text-sm RADIO
</template>

<style lang="sass" scoped>
#name
    // color: #036
    color: #FA0
.radio
    // color: #1F3
    color: #F7a
    
</style>