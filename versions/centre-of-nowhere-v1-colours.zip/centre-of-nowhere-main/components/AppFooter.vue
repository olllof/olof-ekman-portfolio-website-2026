<template lang="pug">
footer#app-footer
    .text-right.text-xs 
        | Footer &copy; 2023
    
</template>
